package ru.demo.tradeapp.repository;

import ru.demo.tradeapp.models.Order;

public class OrderDao  extends BaseDao<Order> {
    public OrderDao() {
        super(Order.class);
    }
}
