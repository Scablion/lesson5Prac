package ru.demo.tradeapp.repository;

import ru.demo.tradeapp.models.PickupPoint;

public class PickupPointDao extends BaseDao<PickupPoint> {
    public PickupPointDao() {
        super(PickupPoint.class);
    }
}
